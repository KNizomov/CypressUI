const service = require('../support/service');
const data = require('../../cypress.json');

describe('Test Case 1', () => {

    beforeEach(() => {
        cy.visit('/my-account/sign-in');
        cy.viewport('macbook-15');
        // calling Login fuction & getting test data from Cypress.js file 
        // creds need to by stored in Cypress.js file
        service.Login(data.username, data.password);
    });

    it('Verify that the user is in Profile page', () => {
        // Once User logged in - below code verify user is Profile page
        // Below wait can be handlled/repelaced by intercept
        cy.wait(9000); // hard coded wait
        cy.url().should('include', '/my-account/home?login=success');  
    });

    it('Add a new Shipping address ', () => {
        //adding new Shipping address 
        // we are assuming user already has an existing address 
        cy.get('a').contains('Shipping Addresses').click();
        cy.get('button').contains('Add Address');
        service.AddNewAddress(data.name, data.street, data.apt, data.city, data.state, data.zipCode, data.phoneNumber);
    });

});