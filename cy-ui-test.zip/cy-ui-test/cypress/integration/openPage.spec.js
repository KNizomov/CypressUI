// openPage.spec.js created with Cypress
describe('Open a Brower and perform some UI activity', () => {
    it('Use valid credentials to login', () => {
        
        cy.visit('/my-account/sign-in');

    });
})

