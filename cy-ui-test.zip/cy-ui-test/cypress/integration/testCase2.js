const service = require('../support/service');
const data = require('../../cypress.json');



// Waits on tests can be handlled by intercept
describe('Test Case 2', () => {

    beforeEach(() => {
        cy.visit('/my-account/sign-in');
        cy.viewport('macbook-15');
        // calling Login fuction & getting test data from Cypress.js file 
        // creds need to by stored in Cypress.js file
        service.Login(data.username, data.password);
    });

    it('Verify that the url contains boys when the category page loads', () => {
        //another way we can also click by button
        cy.wait(5000);
        //cy.get('button').contains('Boys').click();
        cy.get('[data-testid="ahref_Boys"]').click();
        cy.url().should('include', 'Boys');
    });

    it('Verify that the url contains Toddler when the category page loads', () => {
        //another way we can also click by button
        cy.wait(5000);
        //cy.get('button').contains('Toddler').click();
        cy.get('[data-testid="ahref_Toddler"]').click();
        cy.url().should('include', 'Toddler');
    });
});