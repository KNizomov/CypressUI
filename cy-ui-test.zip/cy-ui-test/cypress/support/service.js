


function Login(username , password) {
    cy.visit('/my-account/sign-in');
    cy.get('[id = "verify-account-email"]').type(username);
    cy.get('button').contains('Continue').click();
    cy.get('[data-testid="password-input"]').type(password);
    cy.get('[class="loyalty-signInForm-button cb_fixed-button-primary css-0"]').click();
}

function AddNewAddress(fullName, street, apt, city, state, zip, phone ) {
    cy.get('[name = "fullName"]').type(fullName);
    cy.get('[name = "addressLine1"]').type(street);
    cy.get('[name = "addressLine2"]').type(apt);
    cy.get('[name="city"]').type(city);
    cy.get("#described-by").click();
    cy.get('ul>li').contains(state).click();
    cy.get('[name = "zipCode"]').type(zip);
    cy.get('[name = "dayPhone"]').type(phone);
    cy.get('button').contains('Save Address').click();
}


export default {
    Login,
    AddNewAddress
}